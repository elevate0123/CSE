// Minimal service worker — satisfies Chrome PWA installability requirement
// Network-first: always tries network, no offline caching
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (e) => {
  e.respondWith(fetch(e.request));
});
