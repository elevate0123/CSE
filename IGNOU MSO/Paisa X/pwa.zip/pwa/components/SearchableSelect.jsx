'use client';
import { useState, useRef, useEffect } from 'react';

export default function SearchableSelect({ label, options, value, onChange, placeholder = 'Select…' }) {
  const [open, setOpen]     = useState(false);
  const [query, setQuery]   = useState('');
  const inputRef            = useRef(null);

  const filtered = query.trim()
    ? options.filter(o => o.toLowerCase().includes(query.toLowerCase()))
    : options;

  // Short display label: last two segments (e.g. "Food:Groceries")
  const display = value
    ? value.split(':').slice(-2).join(':')
    : null;

  function select(opt) {
    onChange(opt);
    setOpen(false);
    setQuery('');
  }

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 80);
  }, [open]);

  // Close on backdrop tap
  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (e.target.id === 'ss-backdrop') setOpen(false);
    };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, [open]);

  return (
    <>
      <div>
        <label className="block text-sm font-medium text-gray-600 mb-1">{label}</label>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className={`w-full text-left px-4 py-3.5 rounded-xl border-2 text-base bg-white
            ${value ? 'border-navy text-gray-900' : 'border-gray-200 text-gray-400'}
            focus:outline-none active:bg-gray-50`}
        >
          {display || placeholder}
          <span className="float-right text-gray-400">▾</span>
        </button>
      </div>

      {/* Bottom sheet */}
      {open && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end">
          {/* Backdrop */}
          <div
            id="ss-backdrop"
            className="absolute inset-0 bg-black/40"
          />
          {/* Sheet */}
          <div className="relative bg-white rounded-t-2xl max-h-[75vh] flex flex-col shadow-2xl">
            {/* Handle */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-gray-300" />
            </div>
            {/* Label */}
            <div className="px-4 pb-2 text-sm font-semibold text-gray-500 uppercase tracking-wide">
              {label}
            </div>
            {/* Search */}
            <div className="px-4 pb-3">
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search…"
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 text-base
                  focus:outline-none focus:border-navy"
              />
            </div>
            {/* List */}
            <ul className="overflow-y-auto flex-1 pb-6">
              {filtered.length === 0 && (
                <li className="px-6 py-4 text-gray-400 text-sm">No results</li>
              )}
              {filtered.map(opt => {
                const parts = opt.split(':');
                const main  = parts.slice(-1)[0];
                const sub   = parts.slice(0, -1).join(':');
                const active = opt === value;
                return (
                  <li key={opt}>
                    <button
                      type="button"
                      onClick={() => select(opt)}
                      className={`w-full text-left px-6 py-3.5 flex items-center gap-3
                        active:bg-blue-50
                        ${active ? 'bg-blue-50' : ''}`}
                    >
                      {active && <span className="text-navy text-lg">✓</span>}
                      <span className={active ? 'ml-0' : 'ml-7'}>
                        <span className="text-base font-medium text-gray-900">{main}</span>
                        <span className="block text-xs text-gray-400">{sub}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      )}
    </>
  );
}
