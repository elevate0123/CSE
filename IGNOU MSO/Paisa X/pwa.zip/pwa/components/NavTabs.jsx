'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function NavTabs() {
  const path = usePathname();
  const isExpense  = path === '/';
  const isTransfer = path === '/transfer';

  const base    = 'flex-1 py-3 text-sm font-semibold text-center transition-colors';
  const active  = 'text-white border-b-2 border-white';
  const inactive = 'text-blue-200 border-b-2 border-transparent';

  return (
    <div className="bg-navy flex">
      <Link href="/"         className={`${base} ${isExpense  ? active : inactive}`}>Expense</Link>
      <Link href="/transfer" className={`${base} ${isTransfer ? active : inactive}`}>Transfer</Link>
    </div>
  );
}
