import './globals.css';
import NavTabs from '@/components/NavTabs';

export const metadata = {
  title: 'AlmFin',
  description: 'Household finance entry',
  manifest: '/manifest.json',
  appleWebApp: { capable: true, statusBarStyle: 'default', title: 'AlmFin' },
  other: { 'mobile-web-app-capable': 'yes' },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#1c3557',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="apple-touch-icon" href="/icon-192.png" />
      </head>
      <body>
        {/* Header */}
        <header className="bg-navy text-white">
          <div className="px-5 pt-5 pb-3">
            <h1 className="text-xl font-bold tracking-tight">AlmFin</h1>
            <p className="text-blue-200 text-xs mt-0.5">Household Finance</p>
          </div>
          <NavTabs />
        </header>

        {/* Page content */}
        <main className="max-w-lg mx-auto px-4 py-6 pb-24">
          {children}
        </main>

        {/* Service worker registration */}
        <script dangerouslySetInnerHTML={{
          __html: `
            if ('serviceWorker' in navigator) {
              window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js').catch(() => {});
              });
            }
          `
        }} />
      </body>
    </html>
  );
}
