import { NextResponse } from 'next/server';
import { appendAndCommit } from '@/lib/github';
import { getJournalPath, formatExpenseEntry, PAYMENT_ACCOUNTS } from '@/lib/constants';

export async function POST(request) {
  try {
    const data = await request.json();
    const { date, description, amount, category, paidVia, notes } = data;

    // ── Validate
    const errors = [];
    if (!date)        errors.push('date');
    if (!description) errors.push('description');
    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) errors.push('amount');
    if (!category)    errors.push('category');
    if (!paidVia)     errors.push('paidVia');
    if (!PAYMENT_ACCOUNTS[paidVia]) errors.push(`unknown paidVia: ${paidVia}`);
    if (errors.length) {
      return NextResponse.json({ error: `Missing/invalid: ${errors.join(', ')}` }, { status: 400 });
    }

    const path  = getJournalPath(date);
    const entry = formatExpenseEntry({ date, description, amount, category, paidVia, notes });
    const msg   = `add: ${date} ${description.trim()} ₹${parseFloat(amount).toFixed(0)}`;

    await appendAndCommit(path, entry, msg);

    return NextResponse.json({ success: true, path });
  } catch (err) {
    console.error('[add-expense]', err.message);
    if (err.message === 'CONFLICT') {
      return NextResponse.json({ error: 'Save conflict — please try again.' }, { status: 409 });
    }
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
