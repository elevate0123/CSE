import { NextResponse } from 'next/server';
import { appendAndCommit } from '@/lib/github';
import { getJournalPath, formatTransferEntry, TRANSFER_ACCOUNTS } from '@/lib/constants';

export async function POST(request) {
  try {
    const data = await request.json();
    const { date, description, amount, fromAccount, toAccount, notes } = data;

    // ── Validate
    const errors = [];
    if (!date)         errors.push('date');
    if (!description)  errors.push('description');
    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) errors.push('amount');
    if (!fromAccount || !TRANSFER_ACCOUNTS.includes(fromAccount)) errors.push('fromAccount');
    if (!toAccount   || !TRANSFER_ACCOUNTS.includes(toAccount))   errors.push('toAccount');
    if (fromAccount === toAccount) errors.push('from and to accounts must differ');
    if (errors.length) {
      return NextResponse.json({ error: `Missing/invalid: ${errors.join(', ')}` }, { status: 400 });
    }

    const path  = getJournalPath(date);
    const entry = formatTransferEntry({ date, description, amount, fromAccount, toAccount, notes });
    const msg   = `add: ${date} ${description.trim()} ₹${parseFloat(amount).toFixed(0)}`;

    await appendAndCommit(path, entry, msg);

    return NextResponse.json({ success: true, path });
  } catch (err) {
    console.error('[add-transfer]', err.message);
    if (err.message === 'CONFLICT') {
      return NextResponse.json({ error: 'Save conflict — please try again.' }, { status: 409 });
    }
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
