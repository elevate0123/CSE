'use client';
import { useState, useEffect } from 'react';
import SearchableSelect from '@/components/SearchableSelect';
import { EXPENSE_ACCOUNTS, PAYMENT_ACCOUNTS } from '@/lib/constants';

const PAYMENT_METHODS = Object.keys(PAYMENT_ACCOUNTS);

function today() {
  return new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD
}

const STORAGE_KEY = 'almfin_expense_prefs';
function loadPrefs() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
  catch { return {}; }
}
function savePrefs(prefs) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs)); } catch {}
}

export default function ExpensePage() {
  const [form, setForm] = useState({
    date: today(), description: '', amount: '', category: '', paidVia: '', notes: '',
  });
  const [status, setStatus]   = useState(null); // null | 'loading' | 'success' | 'error'
  const [message, setMessage] = useState('');

  // Restore last-used category + paidVia
  useEffect(() => {
    const prefs = loadPrefs();
    setForm(f => ({ ...f, category: prefs.category || '', paidVia: prefs.paidVia || '' }));
  }, []);

  function set(field, value) {
    setForm(f => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.description || !form.amount || !form.category || !form.paidVia) {
      setStatus('error');
      setMessage('Please fill in Description, Amount, Category and Paid Via.');
      return;
    }
    setStatus('loading');
    setMessage('');
    try {
      const res = await fetch('/api/add-expense', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Unknown error');

      // Save prefs, reset form (keep category + paidVia)
      savePrefs({ category: form.category, paidVia: form.paidVia });
      setMessage(`₹${parseFloat(form.amount).toFixed(0)} — ${form.description}`);
      setStatus('success');
      setForm(f => ({ date: today(), description: '', amount: '', category: f.category, paidVia: f.paidVia, notes: '' }));
    } catch (err) {
      setStatus('error');
      setMessage(err.message);
    }
  }

  function addAnother() {
    setStatus(null);
    setMessage('');
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">

      {/* Success banner */}
      {status === 'success' && (
        <div className="rounded-2xl bg-green-50 border border-green-200 p-4 flex items-start gap-3">
          <span className="text-2xl">✅</span>
          <div className="flex-1">
            <p className="font-semibold text-green-800">Saved to GitHub</p>
            <p className="text-sm text-green-700 mt-0.5">{message}</p>
          </div>
          <button type="button" onClick={addAnother}
            className="text-sm font-semibold text-green-700 underline">
            + Add
          </button>
        </div>
      )}

      {/* Error banner */}
      {status === 'error' && (
        <div className="rounded-2xl bg-red-50 border border-red-200 p-4 flex items-start gap-3">
          <span className="text-2xl">⚠️</span>
          <div className="flex-1">
            <p className="font-semibold text-red-800">Error</p>
            <p className="text-sm text-red-700 mt-0.5">{message}</p>
          </div>
          <button type="button" onClick={() => setStatus(null)}
            className="text-sm font-semibold text-red-700 underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Date */}
      <div>
        <label className="block text-sm font-medium text-gray-600 mb-1">Date</label>
        <input type="date" value={form.date} onChange={e => set('date', e.target.value)}
          className="w-full px-4 py-3.5 rounded-xl border-2 border-gray-200 text-base bg-white
            focus:outline-none focus:border-navy" />
      </div>

      {/* Amount — most prominent */}
      <div>
        <label className="block text-sm font-medium text-gray-600 mb-1">Amount (₹)</label>
        <div className="relative">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl font-semibold text-gray-400">₹</span>
          <input
            type="number" inputMode="decimal" step="0.01" min="0"
            value={form.amount} onChange={e => set('amount', e.target.value)}
            placeholder="0.00"
            className="w-full pl-9 pr-4 py-4 rounded-xl border-2 border-gray-200 text-2xl font-bold bg-white
              focus:outline-none focus:border-navy placeholder:text-gray-300"
            autoFocus
          />
        </div>
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-gray-600 mb-1">Description</label>
        <input type="text" value={form.description} onChange={e => set('description', e.target.value)}
          placeholder="e.g. DMart groceries"
          className="w-full px-4 py-3.5 rounded-xl border-2 border-gray-200 text-base bg-white
            focus:outline-none focus:border-navy placeholder:text-gray-400" />
      </div>

      {/* Category — searchable */}
      <SearchableSelect
        label="Category"
        options={EXPENSE_ACCOUNTS}
        value={form.category}
        onChange={v => set('category', v)}
        placeholder="Select expense category…"
      />

      {/* Paid Via */}
      <div>
        <label className="block text-sm font-medium text-gray-600 mb-1">Paid Via</label>
        <select value={form.paidVia} onChange={e => set('paidVia', e.target.value)}
          className={`w-full px-4 py-3.5 rounded-xl border-2 text-base bg-white
            focus:outline-none focus:border-navy appearance-none
            ${form.paidVia ? 'border-navy text-gray-900' : 'border-gray-200 text-gray-400'}`}>
          <option value="">Select payment method…</option>
          {PAYMENT_METHODS.map(m => <option key={m} value={m}>{m}</option>)}
        </select>
      </div>

      {/* Notes */}
      <div>
        <label className="block text-sm font-medium text-gray-600 mb-1">Notes <span className="text-gray-400 font-normal">(optional)</span></label>
        <input type="text" value={form.notes} onChange={e => set('notes', e.target.value)}
          placeholder="e.g. includes vegetables"
          className="w-full px-4 py-3.5 rounded-xl border-2 border-gray-200 text-base bg-white
            focus:outline-none focus:border-navy placeholder:text-gray-400" />
      </div>

      {/* Submit */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-100">
        <button type="submit" disabled={status === 'loading'}
          className="w-full py-4 rounded-2xl bg-navy text-white text-lg font-bold
            disabled:opacity-50 active:scale-95 transition-transform max-w-lg mx-auto block">
          {status === 'loading' ? 'Saving…' : 'Add Expense'}
        </button>
      </div>

    </form>
  );
}
